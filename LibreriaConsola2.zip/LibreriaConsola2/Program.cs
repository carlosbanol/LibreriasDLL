﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Libreria;

namespace LibreriaConsola2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            long suma;
            int resta;
            long multi;
            float division;

            suma = Libreria.Class1.Suma(5, 2);
            resta = Libreria.Class1.Resta(5, 2);
            multi = Libreria.Class1.Multiplicacion(5, 2);
            division = Libreria.Class1.Division(5, 2);

            Console.WriteLine("La suma total es:" + suma.ToString());
            Console.WriteLine("La resta total de: " + resta.ToString());
            Console.WriteLine("La multiplicación total es: " + multi.ToString());
            Console.WriteLine("La división total es: " + division.ToString());
            Console.ReadKey();

        }
    }
}
