﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria
{
    public class Class1
    {

        /// <Summary>
        /// Método sumar
        /// 

        public static long Suma(long i, long j)
        {
            return i + j;
        }

        public static int Resta(int i, int j)
        {
            return i - j;
        }

        public static long Multiplicacion(long i, long j)
        {
            return i * j;
        }

        public static float Division(float i, float j)
        {
            return i / j;
        }
    }
}
